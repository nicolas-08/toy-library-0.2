What's in the package:
1. toy-library-0.2: springboot backend
2. toy-library-0.2-front: springboot frontend
3. Screenshot-*.PNG: application screenshots
4. README.txt: this document

Instructions:
1. unzip toy-library-0.2. And run: mvn install then npm start
2. get toy-library-0.0.1-SNAPSHOT.jar from target folder 
3. run: java -jar toy-library-0.0.1-SNAPSHOT.jar
4. unzip toy-library-0.2-front.zip. And run: npm start
5. go to your favorite browser type http://localhost:4200
6. DONE.

Author: Lei Huang 
Email:  nicolas.818@gmail.com
